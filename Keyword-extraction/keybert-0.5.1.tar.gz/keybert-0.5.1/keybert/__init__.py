from keybert._model import KeyBERT

__version__ = "0.5.1"
